<?php
include 'db_connection.php';
session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    if (empty($username) || empty($password)) {
        $message = "Both username and password are required!";
    } else {
        $sql = "SELECT * FROM users WHERE Username='$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (isset($user['Password']) && password_verify($password, $user['Password'])) {
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                header("Location: Home.php");
                exit();
            } else {
                $message = "Invalid password!";
            }
        } else {
            $message = "Invalid username!";
        }
    }

    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HealthCare Hospital</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>WELCOME TO UNESWA HEALTHCARE HOSPITAL</h1>
    </header>

    <section class="main-content">
        <h2>Please Login</h2><br>
        <p>Please log in to access your account and manage your appointments.</p>

        <form id="loginForm" class="form-container" action="login.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter your username" required><br><br>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter your password" required><br><br>

            <button type="submit">Login</button>
            <button type="button" onclick="window.location.href='registration.html'">Register</button>
        </form>

        <div id="loginMessage"><?php echo $message; ?></div>
    </section>

    <footer>
        <p>&copy; 2024 HealthCare Hospital. All Rights Reserved.</p>
    </footer>
</body>
</html>
