<?php
include 'db_connection.php';

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $doctor = $_POST['doctor'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    // Check for existing appointment
    $sql_check = "SELECT * FROM appointments WHERE doctor='$doctor' AND appointment_date='$appointment_date' AND appointment_time='$appointment_time'";
    $result_check = $conn->query($sql_check);

    if ($result_check->num_rows > 0) {
        $response['status'] = 'error';
        $response['message'] = "Doctor $doctor is booked, please try another time with intervals of 2 hours. Thank you";
    } else {
        // Insert appointment into the database
        $sql_insert = "INSERT INTO appointments (name, doctor, appointment_date, appointment_time) VALUES ('$name', '$doctor', '$appointment_date', '$appointment_time')";
        if ($conn->query($sql_insert) === TRUE) {
            $response['status'] = 'success';
            $response['message'] = 'Appointment made';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Error: ' . $sql_insert . '<br>' . $conn->error;
        }
    }

    $conn->close();
}

echo json_encode($response);
?>
