<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uneswa HealthCare Hospital - Home</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .logout-button {
            position: absolute;
            right: 20px;
            top: 20px;
            background-color: #00539C;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php include 'session_check.php'; ?>
    <header>
        <h1>Welcome to Uneswa HealthCare Hospital</h1>
        <nav><br><br>
            <ul>
                <li><a href="Home.php">Home</a></li>
                <li><a href="Appointments.html">Book Appointment</a></li>
                <li><a href="Doctors.html">Our Doctors</a></li>
                <li><a href="Feedback.html">Feedback</a></li>
            </ul>
        </nav>
        <button class="logout-button" onclick="window.location.href='logout.php'">Logout</button>
    </header>

<!-- Homepage Section -->
    <section id="doctors" class="main-content">
        <h2>Your Health, Our Priority</h2><br>
        <div class="doctor-list">
            <div class="doctor">
                <h3>We are committed to providing you the best healthcare services with minimum waiting time.</h3>
                <br></br>
                <p>Nestled in the heart of Eswatini, Uneswa Hospital stands as a beacon of hope and healing. With a commitment to excellence and a patient-centric approach, Uneswa Hospital offers a comprehensive range of medical services. From routine check-ups to complex surgeries, our dedicated team of highly trained doctors and medical professionals cater to every healthcare need with unparalleled expertise and compassion.<br></br>
                    
                At Uneswa Hospital, our team of skilled cardiologists is dedicated to diagnosing and treating heart-related conditions. Equipped with cutting-edge technology and a deep understanding of cardiovascular health, they manage everything from routine heart check-ups to complex procedures like angioplasties and bypass surgeries. Their commitment to patient care ensures that each individual receives personalized and effective treatment to maintain and improve their heart health.<br></br>

                Our pediatricians at Uneswa Hospital specialize in the health and well-being of children from birth through adolescence. They provide comprehensive care, including routine check-ups, immunizations, and treatment of childhood illnesses. These doctors are not only medically adept but also excel in creating a comforting environment for young patients and their families, ensuring that children receive the best care in a supportive and nurturing setting.<br></br>

                The general surgeons at Uneswa Hospital are proficient in a wide range of surgical procedures. From emergency surgeries to planned operations, they handle cases involving the abdomen, breast, thyroid, and more. Their expertise and precision are crucial in delivering successful surgical outcomes, and they are supported by a highly trained surgical team and state-of-the-art operating facilities to provide the best possible care for patients.<br></br>

                Gynecologists at Uneswa Hospital are dedicated to women's health, offering services from routine gynecological exams to complex reproductive health surgeries. They provide care for a variety of conditions such as menstrual disorders, menopause, and fertility issues. With a focus on holistic care, these specialists are committed to supporting women through every stage of life, ensuring they receive personalized and compassionate medical attention.<br></br>

                Dermatologists at Uneswa Hospital are experts in skin health, treating a wide array of conditions, from acne and eczema to more serious issues like skin cancer. They utilize the latest techniques and treatments to address both medical and cosmetic dermatological concerns. By offering tailored care plans and preventive measures, our dermatologists help patients achieve healthy, glowing skin, and improve their overall quality of life.<br></br>
                   
                At Uneswa Hospital, we pride ourselves on our diverse and specialized medical staff. Each doctor brings a wealth of knowledge and a passion for their field, ensuring that every patient receives personalized and effective treatment. Our state-of-the-art facilities and advanced medical technology further enhance the quality of care we offer.</p>
            </div>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 HealthCare Hospital. All Rights Reserved.</p>
    </footer>
</body>
</html>
